export default [
    {
        id: "0",
        name: "Farmhouse",
        description: "Delightful combination of onion, capsicum, tomato & grilled mushroom",
        price: "459",
        image: "https://images.dominos.co.in/farmhouse.png",
        tags: true
    },
    {
        id: "1",
        name: "Margherita",
        description: "Delightful combination of onion, capsicum, tomato & grilled mushroom",
        price: "239",
        image: "https://images.dominos.co.in/new_margherita_2502.jpg",
        tags: true
    },
    {
        id: "2",
        name: "Veg Extravaganza",
        description: "Black olives, capsicum, onion, grilled mushroom, corn, tomato, jalapeno & extra cheese",
        price: "549",
        image: "https://images.dominos.co.in/new_veg_extravaganza.jpg",
        tags: true
    }
]